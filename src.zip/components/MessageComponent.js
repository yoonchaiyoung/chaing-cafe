// MessagePresenter 역할
// container는 언제나 component를 포함한다.
// MessageContainer의 자식이 MessageComponent

import React from "react";
import styled from "styled-components";
import BrownProfileContainer from "../container/BrownProfileContainer";

const MessagePresentationContainer = styled.div`
  overflow: scroll;
  display: flex;
  flex-direction: column;
  height: 100%;
`;

// 말풍선을 담을 박스
// 말풍선이 여기에 추가되면서 화면에 뜰 것
const MessageComponent = () => {
  return (
    <MessagePresentationContainer>
      {/* 단계 3. */}
      <BrownProfileContainer />
    </MessagePresentationContainer>
  );
};

export default MessageComponent;
