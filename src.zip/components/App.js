import GlobalStyles from "./GlobalStyles";
import styled from "styled-components";
import MessageContainer from "../container/MessageContainer";
import InputMessageContainer from "../container/InputMessageContainer";

// 원래는 여기에 만들면 안 되는 데 이번에는 App.js에 모든 데이터를 넣겠음
// 화면 가운데에 채팅화면 뜨게 스타일링
const MainContainer = styled.div`
  margin: auto;
  /* margin: auto -> 위, 아래, 양, 옆을 가질 수 있는 최대의 margin을 가지게 된다. */
  max-width: 640px;
  /* 핸드폰까지 같이 고려할 때 */
  height: 80vh;
  /* vh : vertical height : 화면 세로 길이의 80%만 차지하도록. 
  80hw : horizontal width : 화면 가로 길이의 80%만 차지하도록. */
  display: flex;
  flex-direction: column;
  /* 위에 채팅창
  밑에 입력창
  세로로 쌓을 거라서 column */
`;

function App() {
  return (
    <>
      <GlobalStyles />
      <MainContainer>
        <MessageContainer />
        {/* MessageComponent를 바로 호출하는 것이 아닌 부모인 MessageContainer부터 호출한다. */}
        <InputMessageContainer />
      </MainContainer>
    </>
  );
}

export default App;
