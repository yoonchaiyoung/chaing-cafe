import React from "react";
import InputMessageComponent from "../components/InputMessageComponent";

const InputMessageContainer = () => {
  return <InputMessageComponent />;
};

export default InputMessageContainer;
