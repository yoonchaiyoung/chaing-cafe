import React from "react";
import BrownProfileComponent from "../components/BrownProfileComponent";

const BrownProfileContainer = () => {
  // 단계 1. component 연결
  return <BrownProfileComponent />;
};

export default BrownProfileContainer;
