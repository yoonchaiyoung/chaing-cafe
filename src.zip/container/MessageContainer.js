import React from "react";
import MessageComponent from "../components/MessageComponent";

const MessageContainer = () => {
  return <MessageComponent />;
};

export default MessageContainer;
